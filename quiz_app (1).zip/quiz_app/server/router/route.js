import { Router } from "express";
const router = Router();

//import controllers
import * as controller from "../controllers/controller.js";
import { get } from "mongoose";
//Question routes API
// router.get('/questions' , controller.getQuestions)
// router.post('/questions' , controller.inserQuestions)

router
  .route("/api/questions")
  .get(controller.getQuestions)
  .post(controller.insertQuestions)
  .delete(controller.dropQuestions);

router
  .route("/result")
  .get(controller.getResult)
  .post(controller.storeResult)
  .delete(controller.dropResult);
export default router;
