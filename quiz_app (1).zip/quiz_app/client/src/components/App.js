// // import logo from './logo.svg';
// import '../styles/App.css';

// import {createBrowserRouter , RouterProvider } from 'react-router-dom'

// // import components
// import Main from './Main';
// import Quiz from './Quiz';
// import Result from './Result';
// /* React Routers */
// const router = createBrowserRouter([
//   {
//     path : '/',
//     element : <Main></Main>
//   },
//   {
//     path : '/quiz',
//     element : <Quiz></Quiz>
//   },
//   {
//     path : '/result',
//     element : <Result></Result>
//   },
// ])
// function App() {
//   return (
//     <>
//     <RouterProvider router = {router} />
//     </>
//   );
// }

// export default App;



// import '../styles/App.css';

// import { createBrowserRouter, RouterProvider } from 'react-router-dom'

// /** import components */
// import Main from './Main';
// import Quiz from './Quiz';
// import Result from './Result';
// import { CheckUserExist } from '../helper/helper';


// /** react routes */
// const router = createBrowserRouter([
//   {
//     path : '/',
//     element : <Main></Main>
//   },
//   {
//     path : '/quiz',
//     element : <CheckUserExist><Quiz /></CheckUserExist>
//   },
//   {
//     path : '/result',
//     element : <CheckUserExist><Result /></CheckUserExist>
//   },
// ])

// function App() {
//   return (
//     <>
//       <RouterProvider router={router} />
//     </>
//   );
// }

// export default App;
// import { useSelector } from 'react-redux';
// import { Navigate } from 'react-router-dom';

// export function CheckUserExist({ children }) {
//   const userId = useSelector((state) => state.user.id);
  
//   if (!userId) {
//     return <Navigate to="/" replace />;
//   }

//   return children;
// }


import '../styles/App.css';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';

/** import components */
import Main from './Main';
import Quiz from './Quiz';
import Result from './Result';
import { CheckUserExist } from '../helper/helper';

/** react routes */
const router = createBrowserRouter([
  {
    path: '/',
    element: <Main />,
  },
  {
    path: '/quiz',
    element: (
      <CheckUserExist>
        <Quiz />
      </CheckUserExist>
    ),
  },
  {
    path: '/result',
    element: (
      <CheckUserExist>
        <Result />
      </CheckUserExist>
    ),
  },
]);

function App() {
  return <RouterProvider router={router} />;
}

export default App;
