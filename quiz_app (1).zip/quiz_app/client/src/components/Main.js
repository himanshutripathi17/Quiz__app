// import React, { useRef } from 'react';
// import { Link } from 'react-router-dom';
// import '../styles/Main.css'
// export default function Main(){

//     const inputRef = useRef(null);
//     return (
//         <div className='container'>
//             <h1 className='title text-light'>QuizzBee</h1>
//             <h2 className='welcome-text'> Welcome to QuizzBee I will walk you through the instructions: </h2>
//             <ol>

//                 <li> 4 points are awarded for each correct answer but 1 point is deducted for every wrong answer  </li>
//                 <li> Each question will have three options from which you have to choose a correct option </li>
//                 <li> You can change your answer until you click on next question additionally you can review your selections before the quiz finishes </li>
//                 <li> Your total points will be reflected at the end of the quiz </li>
//             </ol>
//             <form id = "form">
//                 <input ref = {inputRef} className="userId" type="text" placeholder='Enter your username*' />
//             </form>

//             <div className='Start'>
//                 <Link className='btn' to={'quiz'}>Start Quiz</Link>
//             </div>
//         </div>
//     )
// }

import React, { useRef } from "react";
import { useDispatch } from "react-redux";
import { Link } from "react-router-dom";
import { setUserId } from "../redux/result_reducer";
// Other imports...

import "../styles/Main.css";

export default function Main() {
  const inputRef = useRef(null);
  const dispatch = useDispatch();

  function startQuiz() {
    if (inputRef.current?.value) {
      dispatch(setUserId(inputRef.current?.value));
    }
  }

  return (
    <div className="container">
      <h1 className="title text-light">Quiz Application</h1>

      <ol>
        <li>You will be asked 10 questions one after another.</li>
        <li>10 points is awarded for the correct answer.</li>
        <li>
          Each question has three options. You can choose only one options.
        </li>
        <li>You can review and change answers before the quiz finish.</li>
        <li>The result will be declared at the end of the quiz.</li>
      </ol>

      <form id="form">
        <input
          ref={inputRef}
          className="userid"
          type="text"
          placeholder="Username*"
        />
      </form>

      <div className="start">
        <Link className="btn" to={"quiz"} onClick={startQuiz}>
          Start Quiz
        </Link>
      </div>
    </div>
  );
}
