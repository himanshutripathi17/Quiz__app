// import React, { useEffect, useState } from "react";
// import data from '../database/data';
// import '../styles/Timer.css'; // Ensure the correct path to your CSS

// // Custom Hook
// import { useFetchQuestion } from "../hooks/FetchQuestions";

// export default function Questions() {
//     const [checked, setChecked] = useState(undefined);
//     const [{isLoading  , apiData  , serverError }] = useFetchQuestion()
//     const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);

//     const [timer, setTimer] = useState(10); // Set initial timer to 10 seconds
//     const [progress, setProgress] = useState(100); // Initial progress percentage

//     const question = data[currentQuestionIndex];

//     useEffect(() => {

//         console.log(isLoading);
//         console.log(apiData);
//         console.log(serverError);

//         // Reset timer and progress when a new question is loaded
//         setTimer(10);
//         setProgress(100);

//         const countdown = setInterval(() => {
//             setTimer(prevTimer => {
//                 if (prevTimer > 0) {
//                     const newTime = prevTimer - 1;
//                     setProgress((newTime / 10) * 100); // Update progress percentage
//                     return newTime;
//                 } else {
//                     clearInterval(countdown);
//                     nextQuestion(); // Automatically move to next question when time runs out
//                     return 0;
//                 }
//             });
//         }, 1000);

//         return () => clearInterval(countdown);
//     }, [currentQuestionIndex]);

//     function onSelect(e) {
//         setChecked(e.target.value);  // Capture the selected value
//         console.log('Selected option:', e.target.value);
//     }

//     function nextQuestion() {
//         if (currentQuestionIndex < data.length - 1) {
//             setCurrentQuestionIndex(currentQuestionIndex + 1);
//             setChecked(undefined); // Reset the selected option for the new question
//         }
//     }

//     function prevQuestion() {
//         if (currentQuestionIndex > 0) {
//             setCurrentQuestionIndex(currentQuestionIndex - 1);
//             setChecked(undefined); // Reset the selected option for the new question
//         }
//     }

//     // Ensure that question and options exist before rendering
//     if (!question || !question.options) {
//         return <div>No questions available</div>;
//     }

//     return (
//         <div className="questions">
//             <h2 className="text-light">{question.question}</h2>

//             {/* Circular Timer */}
//             <div
//                 className="circular-timer"
//                 style={{
//                     '--progress': progress,
//                     animation: `countdown 10s linear`  // Trigger the countdown animation
//                 }}>
//                 <span className="timer-text">{timer}s</span>
//             </div>

//             <ul key={question.id}>
//                 {
//                     question.options.map((q, i) => (
//                         <li key={i}>
//                             <input
//                                 type="radio"
//                                 value={q}
//                                 name="options"
//                                 id={`q${i}-option`}
//                                 checked={checked === q}  // Check if this option is selected
//                                 onChange={onSelect}  // Pass the handler correctly
//                             />
//                             <label className="text-primary" htmlFor={`q${i}-option`}>{q}</label>
//                             <div className={`check ${checked === q ? 'checked' : ''}`}></div>
//                         </li>
//                     ))
//                 }
//             </ul>

//             <div className="grid">
//                 <button className="btn prev" onClick={prevQuestion} disabled={currentQuestionIndex === 0}>
//                     Previous
//                 </button>
//                 <button className="btn next" onClick={nextQuestion} disabled={currentQuestionIndex === data.length - 1}>
//                     Next
//                 </button>
//             </div>
//         </div>
//     );
// }

// import React, { useEffect, useState } from "react";
// import data from '../database/data';
// import '../styles/Timer.css';
// import { useDispatch, useSelector } from "react-redux";
// // Custom Hook
// import { useFetchQuestion } from "../hooks/FetchQuestions";
// //import { updateResultAction } from "../Redux/result_reducer";
// import { updateResult } from "../hooks/setResult";

// export default function Questions({onChecked}) {
//     const [checked, setChecked] = useState(undefined);
//     const {trace} = useSelector(state => state.questions);
//     const [{ isLoading, apiData, serverError }] = useFetchQuestion();
//     const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
//     const result = useSelector(state => state.result.result)
//     const [timer, setTimer] = useState(10);
//     const [progress, setProgress] = useState(100);
//     const [isPaused, setIsPaused] = useState(false);

//     const question = data[currentQuestionIndex];

//     const questions = useSelector(state => state.questions.queue[state.questions.trace]);
//     const dispatch = useDispatch();
//     useEffect(() => {
//         dispatch(updateResult({trace , checked}))
//     },[checked])

//     useEffect(() => {
//         setTimer(10);
//         setProgress(100);

//         const countdown = setInterval(() => {
//             if (!isPaused) {
//                 setTimer(prevTimer => {
//                     if (prevTimer > 0) {
//                         const newTime = prevTimer - 1;
//                         setProgress((newTime) * 100);
//                         return newTime;
//                     } else {
//                         clearInterval(countdown);
//                         nextQuestion();
//                         return 0;
//                     }
//                 });
//             }
//         }, 1000);

//         return () => clearInterval(countdown);
//     }, [currentQuestionIndex, isPaused]);

//     function onSelect(e) {
//         setChecked(e.target.value);
//       //  console.log('Selected option:', e.target.value);
//         onChecked(e);
//         setChecked(e)
//     }

//     if(isLoading) return <h3 className="text - light">isLoading</h3>;
//     if(serverError) return <h3 className="text - light">{serverError || "Unknown Error"}</h3>;

//     function nextQuestion() {
//         if (currentQuestionIndex < data.length - 1) {
//             setCurrentQuestionIndex(currentQuestionIndex + 1);
//             setChecked(undefined);
//         }
//     }

//     function prevQuestion() {
//         if (currentQuestionIndex > 0) {
//             setCurrentQuestionIndex(currentQuestionIndex - 1);
//             setChecked(undefined);
//         }
//     }

//     function togglePause() {
//         setIsPaused(!isPaused);
//     }

//     if (!question || !question.options) {
//         return <div>No questions available</div>;
//     }

//     return (
//         <div className="questions">
//             <h2 className="text-light">{question?.question}</h2>

//             {/* Circular Timer */}
//             <div
//                 className="circular-timer"
//                 style={{
//                     '--progress': progress,
//                 }}>
//                 <span className="timer-text">{timer}s</span>
//             </div>

//             <ul key={questions?.id}>
//                 {
//                     questions?.options.map((q, i) => (
//                         <li key={i}>
//                             <input
//                                 type="radio"
//                                 value={q}
//                                 name="options"
//                                 id={`q${i}-option`}
//                                 checked={checked === q}
//                                 onChange={() => onSelect(i)}
//                             />
//                             <label className="text-primary" htmlFor={`q${i}-option`}>{q}</label>
//                             <div className={`check ${result[trace] == i ? 'checked' : ''}`}></div>
//                         </li>
//                     ))
//                 }
//             </ul>

//             <div className="grid">
//                 <button className="btn prev" onClick={prevQuestion} disabled={currentQuestionIndex === 0}>
//                     Previous
//                 </button>
//                 <button className="btn next" onClick={nextQuestion} disabled={currentQuestionIndex === data.length - 1}>
//                     Next
//                 </button>
//             </div>

//             <div className="pause-resume-container">
//                 <button className="pause-resume-btn" onClick={togglePause}>
//                     {isPaused ? "Resume" : "Pause"}
//                 </button>
//             </div>
//         </div>
//     );
// }

// Code version

import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

/** Custom Hook */
// import { useFetchQestion } from '../hooks/FetchQuestion'
import { useFetchQestion } from "../hooks/FetchQuestions";

import { updateResult } from "../hooks/setResult";

export default function Questions({ onChecked }) {
  const [checked, setChecked] = useState(undefined);
  const { trace } = useSelector((state) => state.questions);
  const result = useSelector((state) => state.result.result);
  const [{ isLoading, apiData, serverError }] = useFetchQestion();

  const questions = useSelector(
    (state) => state.questions.queue[state.questions.trace]
  );
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(updateResult({ trace, checked }));
  }, [checked]);

  function onSelect(i) {
    onChecked(i);
    setChecked(i);
    dispatch(updateResult({ trace, checked }));
  }

  if (isLoading) return <h3 className="text-light">isLoading</h3>;
  if (serverError) {
    // If serverError is an object, we can either stringify it or access a specific message property.
    const errorMessage = typeof serverError === 'string' ? serverError : serverError.message || "Unknown Error";
    return <h3 className="text-light">{errorMessage}</h3>;
  }
  
  return (
    <div className="questions">
      <h2 className="text-light">{questions?.question}</h2>

      <ul key={questions?.id}>
        {questions?.options.map((q, i) => (
          <li key={i}>
            <input
              type="radio"
              value={false}
              name="options"
              id={`q${i}-option`}
              onChange={() => onSelect(i)}
            />

            <label className="text-primary" htmlFor={`q${i}-option`}>
              {q}
            </label>
            <div
              className={`check ${result[trace] == i ? "checked" : ""}`}
            ></div>
          </li>
        ))}
      </ul>
    </div>
  );
}
