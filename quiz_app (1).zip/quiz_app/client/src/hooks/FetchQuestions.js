// // Fetch Question hook to fetch api data and set value to store

// import { useEffect, useState } from "react";
// import data from "../database/data";
// import { useDispatch } from "react-redux";

// // Redux Action
// import * as Action from '../Redux/question_reducer'

// export const useFetchQuestion = () => {
//     const dispatch = useDispatch();
//     const [getData , setGetData] = useState({isLoading : false , apiData : [] , serverError : null})

//     useEffect(() => {
//         setGetData(prev => ({...prev , isLoading : true}));

//         // Async function to fetch the data
//         (async() => {
//             try {
//                 let question = await data;

//                 if(question.length > 0) {
//                     setGetData(prev => ({...prev , isLoading : false}));
//                     setGetData(prev => ({...prev , apiData : question}));

//                     // Dispatch and action
//                     dispatch(Action.startExamAction(question));
//                 }
//                 else{
//                     throw new Error("No Questions Available Right Now");
//                 }
//             } catch (error) {
//                 setGetData(prev => ({...prev , isLoading : false}));
//                 setGetData(prev => ({...prev , serverError : error}));
//             }
//         })();
//     },[dispatch]);

//     return [getData,setGetData];
// }

// // Moving Action Dispatch Function

// export const moveNextQuestion = () => async (dispatch) => {
//     try {
//         dispatch(Action.moveNextAction()); // inc trace val by 1

//     } catch (error) {
//         console.log(error)
//     }
// }

// // Moving Prev Dispatch Function
// export const movePrevQuestion = () => async (dispatch) => {
//     try {
//         dispatch(Action.movePrevAction());  // dec trace val by 1

//     } catch (error) {
//         console.log(error)
//     }
// }

//Code Version

// import { useEffect, useState } from "react"
// import { useDispatch } from "react-redux";
// import { getServerData } from "../helper/helper";

// /** redux actions */
// import * as Action from './redux/question_reducer'

// /** fetch question hook to fetch api data and set value to store */
// export const useFetchQestion = () => {
//     const dispatch = useDispatch();
//     const [getData, setGetData] = useState({ isLoading : false, apiData : [], serverError: null});

//     useEffect(() => {
//         setGetData(prev => ({...prev, isLoading : true}));

//         /** async function fetch backend data */
//         (async () => {
//             try {
//                 const [{ questions, answers }] = await getServerData(`${process.env.REACT_APP_SERVER_HOSTNAME}/api/questions`, (data) => data)

//                 if(questions.length > 0){
//                     setGetData(prev => ({...prev, isLoading : false}));
//                     setGetData(prev => ({...prev, apiData : questions}));

//                     /** dispatch an action */
//                     dispatch(Action.startExamAction({ question : questions, answers }))

//                 } else{
//                     throw new Error("No Question Avalibale");
//                 }
//             } catch (error) {
//                 setGetData(prev => ({...prev, isLoading : false}));
//                 setGetData(prev => ({...prev, serverError : error}));
//             }
//         })();
//     }, [dispatch]);

//     return [getData, setGetData];
// }

// /** MoveAction Dispatch function */
// export const MoveNextQuestion = () => async (dispatch) => {
//     try {
//         dispatch(Action.moveNextAction()); /** increase trace by 1 */
//     } catch (error) {
//         console.log(error)
//     }
// }

// /** PrevAction Dispatch function */
// export const MovePrevQuestion = () => async (dispatch) => {
//     try {
//         dispatch(Action.movePrevAction()); /** decrease trace by 1 */
//     } catch (error) {
//         console.log(error)
//     }
// }

import { useDispatch } from "react-redux";
import { getServerData } from "../helper/helper";
import * as Action from "../redux/question_reducer"; // Corrected path
import { useEffect, useState } from "react";
// import data from "../../../server/database/data";

export const useFetchQestion = () => {
  const dispatch = useDispatch();
  const [getData, setGetData] = useState({
    isLoading: false,
    apiData: [],
    serverError: null,
  });

  useEffect(() => {
    setGetData((prev) => ({ ...prev, isLoading: true }));

    (async () => {
      try {
        const [{ questions, answers }] = await getServerData(
          `${process.env.REACT_APP_SERVER_HOSTNAME}/api/questions`,
          (data) => data
        );
        // let question = await data;
        // await getServerData('http://localhost:5000/api/result')
        if (questions.length > 0) {
          setGetData((prev) => ({ ...prev, isLoading: false }));
          setGetData((prev) => ({ ...prev, apiData: questions }));

          dispatch(Action.startExamAction({ question: questions, answers }));
        } else {
          throw new Error("No Question Available");
        }
      } catch (error) {
        setGetData((prev) => ({ ...prev, isLoading: false }));
        setGetData((prev) => ({ ...prev, serverError: error }));
      }
    })();
  }, [dispatch]);

  return [getData, setGetData];
};

export const MoveNextQuestion = () => async (dispatch) => {
  try {
    dispatch(Action.moveNextAction());
  } catch (error) {
    console.log(error);
  }
};

export const MovePrevQuestion = () => async (dispatch) => {
  try {
    dispatch(Action.movePrevAction());
  } catch (error) {
    console.log(error);
  }
};
