
// // CENTRAL STORE/SPACE FOR CLIENT

// import { combineReducers, configureStore } from "@reduxjs/toolkit";
// import questionReducer from "./question_reducer";
// import resultReducer from "./result_reducer";

// // Combine the reducers
// const rootReducer = combineReducers({
//     questions: questionReducer,
//     result: resultReducer
// });

// // Create the store with the combined reducer
// export default configureStore({
//     reducer: rootReducer,
// });



// Code Version

// import { combineReducers, configureStore } from '@reduxjs/toolkit';

// /** call reducers */
// import questionReducer from './question_reducer';
// import resultReducer from './redux/result_reducer';



// const rootReducer = combineReducers({
//     questions : questionReducer,
//     result : resultReducer
// })

// /** create store with reducer */
// export default configureStore({ reducer : rootReducer});


import { combineReducers, configureStore } from '@reduxjs/toolkit';
import questionReducer from './question_reducer'; // Assuming it's in the same directory
import resultReducer from './result_reducer'; // Adjusted path for result_reducer

const rootReducer = combineReducers({
    questions: questionReducer,
    result: resultReducer
});

export default configureStore({ reducer: rootReducer });
